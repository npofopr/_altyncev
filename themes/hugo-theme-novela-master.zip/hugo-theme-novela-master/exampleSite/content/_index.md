---
hero:
  heading: Welcome to Novela, the simplest way to start publishing with Hugo.
  maxWidthPX: 652
---
